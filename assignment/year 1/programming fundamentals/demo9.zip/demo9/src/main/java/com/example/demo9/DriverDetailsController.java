package com.example.demo9;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;


public class DriverDetailsController {

    @FXML
    private TextField nameField;

    @FXML
    private TextField ageField;

    @FXML
    private TextField teamField;

    @FXML
    private TextField carField;

    @FXML
    private TextField pointsField;

    @FXML
    private Button saveButton;

    @FXML
    private Button cancelButton;

    private Stage dialogStage;

    private boolean saveClicked = false;

    @FXML
    private void initialize() {
        // Initialize any necessary UI components or data
        saveButton.setOnAction(event -> handleSave());
        cancelButton.setOnAction(event -> handleCancel());
    }

    @FXML
    private void handleSave() {
        if (isInputValid()) {
            // Save the driver details to the database or data model
            saveClicked = true;
            dialogStage.close();
        }
    }

    @FXML
    private void handleCancel() {
        dialogStage.close();
    }



    private boolean isInputValid() {
        StringBuilder errorMessage = new StringBuilder();
        if (nameField.getText() == null || nameField.getText().trim().isEmpty()) {
            errorMessage.append("Name field is required.\n");
        } else if (!nameField.getText().matches("[a-zA-Z]+")) {
            errorMessage.append("Name field cannot contain numbers or special characters.\n");
        }

        if (ageField.getText() == null || ageField.getText().trim().isEmpty()) {
            errorMessage.append("Age field is required.\n");
        } else if (!ageField.getText().matches("\\d+")) {
            errorMessage.append("Age field must be a number.\n");
        }

        if (teamField.getText() == null || teamField.getText().trim().isEmpty()) {
            errorMessage.append("Team field is required.\n");
        } else if (teamField.getText().matches(".*\\d.*")) {
            errorMessage.append("Team field cannot contain numbers.\n");
        }

        if (carField.getText() == null || carField.getText().trim().isEmpty()) {
            errorMessage.append("Car field is required.\n");
        }

        if (pointsField.getText() == null || pointsField.getText().trim().isEmpty()) {
            errorMessage.append("Current points field is required.\n");
        } else if (!pointsField.getText().matches("\\d+")) {
            errorMessage.append("Current points field must be a number.\n");
        }

        if (errorMessage.length() == 0) {
            return true;
        } else {
            // Display the error message(s)
            Alert alert = new Alert(AlertType.ERROR);
            alert.initOwner(dialogStage);
            alert.setTitle("Invalid Input");
            alert.setHeaderText("Please correct invalid fields");
            alert.setContentText(errorMessage.toString());
            alert.showAndWait();
            return false;
        }
    }

    public void setDialogStage(Stage dialogStage) {
        this.dialogStage = dialogStage;
    }

    public boolean isSaveClicked() {
        return saveClicked;
    }

    public String getName() {
        return nameField.getText();
    }

    public int getAge() {
        return Integer.parseInt(ageField.getText());
    }

    public String getTeam() {
        return teamField.getText();
    }

    public String getCar() {
        return carField.getText();
    }

    public int getPoints() {
        return Integer.parseInt(pointsField.getText());
    }

}

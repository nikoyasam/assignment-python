package com.example.demo9;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Modality;
import javafx.stage.Stage;

import java.io.IOException;

public class DriverDetailsApplication extends Application {

    private Stage primaryStage;

    @Override
    public void start(Stage primaryStage) {
        this.primaryStage = primaryStage;
        this.primaryStage.setTitle("Driver Details");

        showDriverDetailsDialog();
    }

    public void showDriverDetailsDialog() {
        try {
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(DriverDetailsApplication.class.getResource("DriverDetails.fxml"));
            AnchorPane page = (AnchorPane) loader.load();

            Stage dialogStage = new Stage();
            dialogStage.setTitle("Add Driver Details");
            dialogStage.initModality(Modality.WINDOW_MODAL);
            dialogStage.initOwner(primaryStage);
            Scene scene = new Scene(page);
            dialogStage.setScene(scene);

            DriverDetailsController controller = loader.getController();
            controller.setDialogStage(dialogStage);

            dialogStage.showAndWait();

            if (controller.isSaveClicked()) {
                // Save the driver details to the database or data model
                System.out.println("Driver saved: " + controller.getName() + ", " + controller.getAge() + ", " +
                        controller.getTeam() + ", " + controller.getCar() + ", " + controller.getPoints());
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        launch(args);
    }
}

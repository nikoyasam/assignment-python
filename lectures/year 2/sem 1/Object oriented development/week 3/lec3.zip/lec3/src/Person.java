public class Person {
    String firstName;
    String lastName;
    int age;

    Person(){

    }

    public Person(String firstName){
        this.firstName = firstName;
    }

    public Person(String firstName, int age){
        this.firstName = firstName;
        this.age = age;
    }

    public Person(String firstName, String lastName){
        this.firstName = firstName;
        this.lastName = lastName;
    }

    public Person(String firstName, String lastName, int age){
        this.firstName = firstName;
        this.lastName = lastName;
        this.age = age;
    }
}
